'use client';

import React, { useState } from 'react';
import { useSettingsScreen } from '../../hooks/useSettingsScreen';

export default function SettingsPage() {
  const { settings, saveSettings, isLoading, isSuccess } = useSettingsScreen();
  const [freq, setFreq] = useState(settings.notificationFrequency);
  const [time, setTime] = useState(settings.preferredStudyTime);
  const [goal, setGoal] = useState(settings.dailyMinutesGoal);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await saveSettings({
      notificationFrequency: freq,
      preferredStudyTime: time,
      dailyMinutesGoal: Number(goal),
      interfaceLanguage: 'pt-BR'
    });
  };

  const handleLogout = () => {
    localStorage.removeItem('user_settings');
    alert("Logout efetuado com sucesso! Redirecionando para as boas-vindas.");
    window.location.href = '/welcome';
  };

  return (
    <div style={{ maxWidth: '600px', margin: '40px auto', padding: '20px', fontFamily: 'sans-serif', backgroundColor: '#fafafa', borderRadius: '12px', border: '1px solid #eaeaea' }}>
      <h2 style={{ margin: '0 0 20px 0', color: '#111827' }}>Configurações da Conta (INT-20)</h2>

      {isSuccess && (
        <div style={{ backgroundColor: '#def7ec', color: '#03543f', padding: '12px', borderRadius: '6px', marginBottom: '16px', fontSize: '14px' }}>
          ✓ Configurações salvas e onboarding atualizado com sucesso!
        </div>
      )}

      <form onSubmit={handleSubmit} style={{ backgroundColor: 'white', padding: '20px', borderRadius: '8px', boxShadow: '0 1px 3px rgba(0,0,0,0.05)' }}>
        <div style={{ marginBottom: '16px' }}>
          <label style={{ display: 'block', fontSize: '14px', fontWeight: 500, marginBottom: '6px', color: '#374151' }}>
            Frequência de Notificações
          </label>
          <select 
            value={freq} 
            onChange={(e: any) => setFreq(e.target.value)}
            style={{ width: '100%', padding: '8px', borderRadius: '6px', border: '1px solid #d1d5db', fontSize: '14px' }}
          >
            <option value="never">Nunca notificar</option>
            <option value="1x">1 vez por dia</option>
            <option value="2x">2 vezes por dia</option>
            <option value="3x">3 vezes por dia</option>
          </select>
        </div>

        <div style={{ marginBottom: '16px' }}>
          <label style={{ display: 'block', fontSize: '14px', fontWeight: 500, marginBottom: '6px', color: '#374151' }}>
            Horário Preferencial de Estudo
          </label>
          <input 
            type="time" 
            value={time} 
            onChange={(e) => setTime(e.target.value)}
            style={{ width: '100%', padding: '8px', borderRadius: '6px', border: '1px solid #d1d5db', fontSize: '14px' }}
          />
        </div>

        <div style={{ marginBottom: '16px' }}>
          <label style={{ display: 'block', fontSize: '14px', fontWeight: 500, marginBottom: '6px', color: '#374151' }}>
            Meta Diária (minutos)
          </label>
          <input 
            type="number" 
            value={goal} 
            onChange={(e) => setGoal(Number(e.target.value))}
            style={{ width: '100%', padding: '8px', borderRadius: '6px', border: '1px solid #d1d5db', fontSize: '14px' }}
            min="5"
          />
        </div>

        <div style={{ marginBottom: '24px' }}>
          <label style={{ display: 'block', fontSize: '14px', fontWeight: 500, marginBottom: '6px', color: '#374151' }}>
            Idioma da Interface (MVP)
          </label>
          <input 
            type="text" 
            value="Português (PT-BR)" 
            disabled 
            style={{ width: '100%', padding: '8px', borderRadius: '6px', border: '1px solid #e5e7eb', backgroundColor: '#f3f4f6', color: '#9ca3af', fontSize: '14px' }}
          />
        </div>

        <button 
          type="submit" 
          disabled={isLoading}
          style={{ width: '100%', backgroundColor: '#4f46e5', color: 'white', border: 'none', padding: '10px', borderRadius: '6px', cursor: 'pointer', fontSize: '14px', fontWeight: 500 }}
        >
          {isLoading ? 'Salvando...' : 'Salvar Alterações'}
        </button>
      </form>

      <div style={{ marginTop: '24px', backgroundColor: 'white', padding: '16px', borderRadius: '8px', boxShadow: '0 1px 3px rgba(0,0,0,0.05)', textAlign: 'center' }}>
        <button 
          onClick={handleLogout}
          style={{ backgroundColor: '#ef4444', color: 'white', border: 'none', padding: '8px 16px', borderRadius: '6px', cursor: 'pointer', fontSize: '14px', fontWeight: 500 }}
        >
          Sair da Conta
        </button>
      </div>

      <div style={{ marginTop: '24px', textAlign: 'center', fontSize: '12px', color: '#6b7280' }}>
        <a href="/privacy" style={{ color: '#6b7280', marginRight: '12px' }}>Política de Privacidade</a>
        <a href="/terms" style={{ color: '#6b7280' }}>Termos de Uso</a>
      </div>
    </div>
  );
}
