'use client';

import React, { useState, useEffect } from 'react';
import NotificationCenter from '../../components/notifications/NotificationCenter';

export default function ProfilePage() {
  const [user, setUser] = useState({
    name: 'Carolaine',
    email: 'carolaine@example.com',
    learningGoal: 'Business Intelligence no Agronegócio',
    language: 'Português (Brasil)',
    level: 12,
    xp: 4520,
    streak: 7
  });

  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState(user.name);

  const handleSaveName = (e: React.FormEvent) => {
    e.preventDefault();
    setUser(prev => ({ ...prev, name: editName }));
    setIsEditing(false);
  };

  return (
    <div style={{ maxWidth: '600px', margin: '40px auto', padding: '20px', fontFamily: 'sans-serif', backgroundColor: '#fafafa', borderRadius: '12px', border: '1px solid #eaeaea' }}>
      <div style={{ display: 'table', width: '100%', marginBottom: '24px' }}>
        <div style={{ display: 'table-cell', verticalAlign: 'middle' }}>
          <h2 style={{ margin: 0, color: '#111827' }}>Meu Perfil (INT-21)</h2>
        </div>
        <div style={{ display: 'table-cell', verticalAlign: 'middle', textAlign: 'right' }}>
          <NotificationCenter />
        </div>
      </div>

      <div style={{ backgroundColor: 'white', padding: '20px', borderRadius: '8px', boxShadow: '0 1px 3px rgba(0,0,0,0.05)', marginBottom: '20px', textAlign: 'center' }}>
        <div style={{ width: '64px', height: '64px', borderRadius: '50%', backgroundColor: '#4f46e5', color: 'white', display: 'block', margin: '0 auto 12px auto', fontSize: '24px', fontWeight: 'bold', lineHeight: '64px', textAlign: 'center' }}>
          {user.name.charAt(0).toUpperCase()}
        </div>
        <h3 style={{ margin: '0 0 4px 0', color: '#111827' }}>{user.name}</h3>
        <p style={{ margin: 0, fontSize: '14px', color: '#6b7280' }}>{user.email}</p>
        <button 
          onClick={() => { setEditName(user.name); setIsEditing(true); }}
          style={{ marginTop: '12px', backgroundColor: 'transparent', border: '1px solid #d1d5db', borderRadius: '6px', padding: '6px 12px', fontSize: '13px', cursor: 'pointer', fontWeight: 500 }}
        >
          Editar Perfil
        </button>
      </div>

      {isEditing && (
        <div style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.4)', display: 'block', zIndex: 1000 }}>
          <div style={{ backgroundColor: 'white', maxWidth: '400px', margin: '100px auto', padding: '24px', borderRadius: '8px', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}>
            <h4 style={{ margin: '0 0 16px 0' }}>Editar Nome</h4>
            <form onSubmit={handleSaveName}>
              <input 
                type="text" 
                value={editName} 
                onChange={(e) => setEditName(e.target.value)}
                style={{ width: '100%', padding: '8px', marginBottom: '16px', borderRadius: '6px', border: '1px solid #d1d5db' }}
                required 
              />
              <div style={{ textAlign: 'right' }}>
                <button type="button" onClick={() => setIsEditing(false)} style={{ background: 'none', border: 'none', marginRight: '12px', cursor: 'pointer', color: '#4b5563' }}>Cancelar</button>
                <button type="submit" style={{ backgroundColor: '#4f46e5', color: 'white', border: 'none', padding: '6px 16px', borderRadius: '6px', cursor: 'pointer' }}>Salvar</button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div style={{ display: 'table', width: '100%', backgroundColor: 'white', padding: '16px', borderRadius: '8px', boxShadow: '0 1px 3px rgba(0,0,0,0.05)', marginBottom: '20px' }}>
        <div style={{ display: 'table-cell', width: '33.33%', textAlign: 'center', borderRight: '1px solid #f3f4f6' }}>
          <span style={{ block: 'block', fontSize: '12px', color: '#6b7280' }}>Nível</span>
          <div style={{ fontSize: '20px', fontWeight: 'bold', color: '#4f46e5', marginTop: '4px' }}>{user.level}</div>
        </div>
        <div style={{ display: 'table-cell', width: '33.33%', textAlign: 'center', borderRight: '1px solid #f3f4f6' }}>
          <span style={{ block: 'block', fontSize: '12px', color: '#6b7280' }}>Total XP</span>
          <div style={{ fontSize: '20px', fontWeight: 'bold', color: '#111827', marginTop: '4px' }}>{user.xp}</div>
        </div>
        <div style={{ display: 'table-cell', width: '33.33%', textAlign: 'center' }}>
          <span style={{ block: 'block', fontSize: '12px', color: '#6b7280' }}>🔥 Streak</span>
          <div style={{ fontSize: '20px', fontWeight: 'bold', color: '#f59e0b', marginTop: '4px' }}>{user.streak} dias</div>
        </div>
      </div>

      <div style={{ backgroundColor: 'white', padding: '16px', borderRadius: '8px', boxShadow: '0 1px 3px rgba(0,0,0,0.05)' }}>
        <h4 style={{ margin: '0 0 12px 0', fontSize: '14px', color: '#374151' }}>Preferências de Aprendizado</h4>
        <p style={{ margin: '0 0 8px 0', fontSize: '14px' }}><strong>Objetivo:</strong> {user.learningGoal}</p>
        <p style={{ margin: '0 0 16px 0', fontSize: '14px' }}><strong>Idioma:</strong> {user.language}</p>
        
        <a href="/achievements" style={{ display: 'inline-block', fontSize: '14px', color: '#4f46e5', textDecoration: 'none', fontWeight: 500 }}>
          🏆 Ver Conquistas e Medalhas (INT-16) →
        </a>
      </div>
      
      <div style={{ marginTop: '20px', textAlign: 'center' }}>
        <a href="/settings" style={{ fontSize: '14px', color: '#4b5563', textDecoration: 'underline' }}>Ir para Configurações</a>
      </div>
    </div>
  );
}
