'use client';

import React, { useState } from 'react';
import { NotificationItem } from '../../types';

export default function NotificationCenter() {
  const [isOpen, setIsOpen] = useState(false);
  const [notifications, setNotifications] = useState<NotificationItem[]>([
    { id: '1', title: 'Hora de praticar!', message: 'Mantenha sua ofensiva ativa hoje.', isRead: false, createdAt: 'Há 10 min' },
    { id: '2', title: 'Conquista Desbloqueada!', message: 'Você atingiu o nível 5.', isRead: true, createdAt: 'Há 2 dias' },
    { id: '3', title: 'Desafio Semanal', message: 'Complete 3 lições até domingo.', isRead: false, createdAt: 'Há 3 dias' }
  ]);

  const unreadCount = notifications.filter(n => !n.isRead).length;

  const markAsRead = (id: string) => {
    setNotifications(prev =>
      prev.map(n => n.id === id ? { ...n, isRead: true } : n)
    );
  };

  return (
    <div style={{ position: 'relative', display: 'inline-block' }}>
      <button 
        onClick={() => setIsOpen(!isOpen)}
        style={{
          background: 'none', border: 'none', position: 'relative', cursor: 'pointer', fontSize: '1.2rem', padding: '8px'
        }}
      >
        🔔
        {unreadCount > 0 && (
          <span style={{
            position: 'absolute', top: 0, right: 0, backgroundColor: '#4f46e5', color: 'white',
            borderRadius: '50%', padding: '2px 6px', fontSize: '10px', fontWeight: 'bold'
          }}>
            {unreadCount}
          </span>
        )}
      </button>

      {isOpen && (
        <div style={{
          position: 'absolute', right: 0, top: '40px', width: '320px', backgroundColor: 'white',
          boxShadow: '0 4px 12px rgba(0,0,0,0.15)', borderRadius: '8px', zIndex: 100, border: '1px solid #e5e7eb', padding: '12px'
        }}>
          <h4 style={{ margin: '0 0 12px 0', fontSize: '14px', borderBottom: '1px solid #f3f4f6', paddingBottom: '8px' }}>
            Centro de Notificações
          </h4>
          <div style={{ maxHeight: '240px', overflowY: 'auto' }}>
            {notifications.length === 0 ? (
              <p style={{ fontSize: '12px', color: '#6b7280', textAlign: 'center' }}>Nenhuma notificação</p>
            ) : (
              notifications.map(n => (
                <div key={n.id} style={{
                  padding: '8px', borderRadius: '6px', marginBottom: '8px',
                  backgroundColor: n.isRead ? '#f9fafb' : '#f0f2ff', borderLeft: `4px solid ${n.isRead ? '#d1d5db' : '#4f46e5'}`
                }}>
                  <div style={{ display: 'table', width: '100%' }}>
                    <div style={{ display: 'table-cell', verticalAlign: 'top' }}>
                      <strong style={{ fontSize: '13px', color: '#111827' }}>{n.title}</strong>
                      <p style={{ margin: '4px 0 0 0', fontSize: '12px', color: '#4b5563' }}>{n.message}</p>
                      <span style={{ fontSize: '10px', color: '#9ca3af' }}>{n.createdAt}</span>
                    </div>
                    {!n.isRead && (
                      <div style={{ display: 'table-cell', verticalAlign: 'middle', textAlign: 'right', width: '60px' }}>
                        <button 
                          onClick={() => markAsRead(n.id)}
                          style={{ fontSize: '10px', backgroundColor: '#4f46e5', color: 'white', border: 'none', borderRadius: '4px', padding: '2px 6px', cursor: 'pointer' }}
                        >
                          Lida
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
