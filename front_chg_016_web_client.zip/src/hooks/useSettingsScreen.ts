import { useState, useEffect } from 'react';
import { UserSettings } from '../types';

export function useSettingsScreen() {
  const [settings, setSettings] = useState<UserSettings>({
    notificationFrequency: '1x',
    preferredStudyTime: '20:00',
    dailyMinutesGoal: 15,
    interfaceLanguage: 'pt-BR'
  });
  const [isLoading, setIsLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  useEffect(() => {
    // Simulando fetch inicial do PATCH /api/v1/users/me
    const saved = localStorage.getItem('user_settings');
    if (saved) setSettings(JSON.parse(saved));
  }, []);

  const saveSettings = async (updatedSettings: UserSettings) => {
    setIsLoading(true);
    setIsSuccess(false);
    try {
      // Mock das chamadas PATCH /api/v1/users/me e POST /api/v1/users/me/onboarding
      await new Promise(resolve => setTimeout(resolve, 800));
      localStorage.setItem('user_settings', JSON.stringify(updatedSettings));
      setSettings(updatedSettings);
      setIsSuccess(true);
      return true;
    } catch (error) {
      console.error("Erro ao salvar configurações", error);
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  return { settings, saveSettings, isLoading, isSuccess };
}
