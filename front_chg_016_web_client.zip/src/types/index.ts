export interface UserProfile {
  name: string;
  email: string;
  learningGoal: string;
  language: string;
  level: number;
  xp: number;
  streak: number;
}

export interface UserSettings {
  notificationFrequency: 'never' | '1x' | '2x' | '3x';
  preferredStudyTime: string;
  dailyMinutesGoal: number;
  interfaceLanguage: 'pt-BR';
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  isRead: boolean;
  createdAt: string;
}
