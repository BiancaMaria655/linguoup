/** @type {import('next').NextConfig} */
const nextConfig = {
  // Mobile-first: enforce strict mode to catch hydration issues early
  reactStrictMode: true,

  // Route auth and onboarding pages without the (group) parentheses in the URL
  // Using conventional folders: /auth/login maps to the auth group
  async redirects() {
    return [
      {
        source: '/login',
        destination: '/auth/login',
        permanent: false,
      },
      {
        source: '/register',
        destination: '/auth/register',
        permanent: false,
      },
    ]
  },
}

module.exports = nextConfig
