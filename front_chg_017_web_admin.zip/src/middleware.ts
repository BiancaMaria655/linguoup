import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export function middleware(request: NextRequest) {
  // Simulação de verificação de token e Role (ex: obtido via cookies ou headers)
  const token = request.cookies.get('admin_token')?.value;
  const userRole = request.cookies.get('user_role')?.value; // 'ADMIN', 'SUPER_ADMIN', ou 'USER'

  const { pathname } = request.nextUrl;

  // Protege todas as rotas que começam com /admin
  if (pathname.startsWith('/admin')) {
    if (!token || (userRole !== 'ADMIN' && userRole !== 'SUPER_ADMIN')) {
      // Se não estiver autenticado ou não for admin, redireciona para o login
      const loginUrl = new URL('/login', request.url);
      return NextResponse.redirect(loginUrl);
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/admin/:path*'],
};
