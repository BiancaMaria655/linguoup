'use client';

import React from 'react';

export default function DashboardPage() {
  const metrics = {
    totalUsers: 1420,
    totalLessons: 48,
    lessonsCompletedToday: 184
  };

  return (
    <div>
      <h2 style={{ fontSize: '24px', fontWeight: 'bold', color: '#111827', marginBottom: '24px' }}>Visão Geral do Sistema</h2>
      
      {/* Metrics Row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '20px', marginBottom: '40px' }}>
        <div style={{ backgroundColor: 'white', padding: '24px', borderRadius: '8px', boxShadow: '0 1px 3px rgba(0,0,0,0.05)', border: '1px solid #e5e7eb' }}>
          <span style={{ fontSize: '14px', color: '#6b7280', fontWeight: 500 }}>Total de Usuários</span>
          <div style={{ fontSize: '28px', fontWeight: 'bold', color: '#111827', marginTop: '8px' }}>{metrics.totalUsers}</div>
        </div>
        <div style={{ backgroundColor: 'white', padding: '24px', borderRadius: '8px', boxShadow: '0 1px 3px rgba(0,0,0,0.05)', border: '1px solid #e5e7eb' }}>
          <span style={{ fontSize: '14px', color: '#6b7280', fontWeight: 500 }}>Total de Lições Ativas</span>
          <div style={{ fontSize: '28px', fontWeight: 'bold', color: '#4f46e5', marginTop: '8px' }}>{metrics.totalLessons}</div>
        </div>
        <div style={{ backgroundColor: 'white', padding: '24px', borderRadius: '8px', boxShadow: '0 1px 3px rgba(0,0,0,0.05)', border: '1px solid #e5e7eb' }}>
          <span style={{ fontSize: '14px', color: '#6b7280', fontWeight: 500 }}>Lições Concluídas Hoje</span>
          <div style={{ fontSize: '28px', fontWeight: 'bold', color: '#10b981', marginTop: '8px' }}>{metrics.lessonsCompletedToday}</div>
        </div>
      </div>

      <div style={{ backgroundColor: 'white', padding: '24px', borderRadius: '8px', border: '1px solid #e5e7eb' }}>
        <h3 style={{ fontSize: '16px', fontWeight: 'bold', marginBottom: '12px' }}>Acesso Rápido a Operações</h3>
        <p style={{ color: '#4b5563', fontSize: '14px', marginBottom: '16px' }}>Utilize o menu lateral ou os atalhos para atualizar a grade curricular e regras de gamificação.</p>
        <div style={{ display: 'flex', gap: '12px' }}>
          <a href="/admin/lessons" style={{ padding: '10px 16px', backgroundColor: '#4f46e5', color: 'white', textDecoration: 'none', borderRadius: '6px', fontSize: '14px' }}>+ Criar Nova Lição</a>
          <a href="/admin/achievements" style={{ padding: '10px 16px', backgroundColor: '#fff', color: '#374151', border: '1px solid #d1d5db', textDecoration: 'none', borderRadius: '6px', fontSize: '14px' }}>Configurar Regras de XP</a>
        </div>
      </div>
    </div>
  );
}
