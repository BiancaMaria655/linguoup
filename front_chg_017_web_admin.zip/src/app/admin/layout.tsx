'use client';

import React from 'react';

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const handleLogout = () => {
    document.cookie = "admin_token=; max-age=0; path=/";
    document.cookie = "user_role=; max-age=0; path=/";
    window.location.href = '/login';
  };

  return (
    <div style={{ display: 'flex', minHeight: '100vh', fontFamily: 'sans-serif', backgroundColor: '#f9fafb' }}>
      {/* Sidebar */}
      <div style={{ width: '260px', backgroundColor: '#1f2937', color: 'white', padding: '24px 16px' }}>
        <h3 style={{ fontSize: '18px', fontWeight: 'bold', marginBottom: '32px', color: '#f3f4f6' }}>Web Admin Portal</h3>
        <nav style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          <a href="/admin/dashboard" style={{ color: '#e5e7eb', textDecoration: 'none', padding: '8px 12px', borderRadius: '6px', backgroundColor: '#374151' }}>📊 Dashboard</a>
          <a href="/admin/lessons" style={{ color: '#e5e7eb', textDecoration: 'none', padding: '8px 12px', borderRadius: '6px' }}>📚 Gerir Lições</a>
          <a href="/admin/achievements" style={{ color: '#e5e7eb', textDecoration: 'none', padding: '8px 12px', borderRadius: '6px' }}>🏆 Conquistas</a>
        </nav>
        <div style={{ marginTop: 'auto', paddingTop: '40px' }}>
          <button onClick={handleLogout} style={{ width: '100%', padding: '8px', backgroundColor: '#ef4444', border: 'none', borderRadius: '6px', color: 'white', cursor: 'pointer', fontWeight: 500 }}>
            Sair do Painel
          </button>
        </div>
      </div>

      {/* Main Content Workspace */}
      <div style={{ flex: 1, padding: '40px' }}>
        {children}
      </div>
    </div>
  );
}
