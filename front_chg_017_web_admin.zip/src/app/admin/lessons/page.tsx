'use client';

import React, { useState } from 'react';
import { useAdminLessons } from '../../../hooks/useAdminQueries';

export default function AdminLessonsPage() {
  const { lessons, createLesson, softDeleteLesson } = useAdminLessons();
  const [showModal, setShowModal] = useState(false);
  const [filterTheme, setFilterTheme] = useState('');

  // Form states
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [level, setLevel] = useState(1);
  const [theme, setTheme] = useState('Agro');
  const [duration, setDuration] = useState(15);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createLesson({ title, description, level, theme, duration, contentJson: '{}' });
    setShowModal(false);
    setTitle(''); setDescription('');
  };

  const filteredLessons = filterTheme 
    ? lessons.filter(l => l.theme.toLowerCase().includes(filterTheme.toLowerCase()))
    : lessons;

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'between', alignItems: 'center', marginBottom: '24px' }}>
        <h2 style={{ fontSize: '24px', fontWeight: 'bold', color: '#111827' }}>Gestão de Lições (/admin/lessons)</h2>
        <button onClick={() => setShowModal(true)} style={{ padding: '10px 16px', backgroundColor: '#4f46e5', color: 'white', border: 'none', borderRadius: '6px', cursor: 'pointer', fontWeight: 'bold' }}>
          + Nova Lição
        </button>
      </div>

      {/* Filters */}
      <div style={{ marginBottom: '20px' }}>
        <input 
          type="text" 
          placeholder="Filtrar por tema..." 
          value={filterTheme}
          onChange={e => setFilterTheme(e.target.value)}
          style={{ padding: '8px 12px', borderRadius: '6px', border: '1px solid #d1d5db', width: '240px' }}
        />
      </div>

      {/* Table */}
      <div style={{ backgroundColor: 'white', borderRadius: '8px', border: '1px solid #e5e7eb', overflow: 'hidden' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
          <thead style={{ backgroundColor: '#f9fafb' }}>
            <tr>
              <th style={{ padding: '12px 16px', fontSize: '13px', color: '#4b5563' }}>Título</th>
              <th style={{ padding: '12px 16px', fontSize: '13px', color: '#4b5563' }}>Tema</th>
              <th style={{ padding: '12px 16px', fontSize: '13px', color: '#4b5563' }}>Nível</th>
              <th style={{ padding: '12px 16px', fontSize: '13px', color: '#4b5563' }}>Duração</th>
              <th style={{ padding: '12px 16px', fontSize: '13px', color: '#4b5563', textAlign: 'right' }}>Ações</th>
            </tr>
          </thead>
          <tbody>
            {filteredLessons.map(lesson => (
              <tr key={lesson.id} style={{ borderTop: '1px solid #e5e7eb' }}>
                <td style={{ padding: '12px 16px', fontSize: '14px', fontWeight: 500 }}>{lesson.title}</td>
                <td style={{ padding: '12px 16px', fontSize: '14px', color: '#4b5563' }}>{lesson.theme}</td>
                <td style={{ padding: '12px 16px', fontSize: '14px', color: '#4b5563' }}>Nível {lesson.level}</td>
                <td style={{ padding: '12px 16px', fontSize: '14px', color: '#4b5563' }}>{lesson.duration} min</td>
                <td style={{ padding: '12px 16px', textAlign: 'right' }}>
                  <button onClick={() => softDeleteLesson(lesson.id)} style={{ color: '#ef4444', background: 'none', border: 'none', cursor: 'pointer', fontSize: '13px' }}>
                    Desativar (Soft Delete)
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Modal Form */}
      {showModal && (
        <div style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.4)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ backgroundColor: 'white', padding: '32px', borderRadius: '8px', width: '460px', boxShadow: '0 4px 12px rgba(0,0,0,0.15)' }}>
            <h3 style={{ marginBottom: '20px', fontWeight: 'bold' }}>Adicionar Nova Lição</h3>
            <form onSubmit={handleSubmit}>
              <div style={{ marginBottom: '12px' }}>
                <label style={{ display: 'block', fontSize: '13px', marginBottom: '4px' }}>Título</label>
                <input type="text" value={title} onChange={e => setTitle(e.target.value)} required style={{ width: '100%', padding: '8px', border: '1px solid #d1d5db', borderRadius: '4px' }} />
              </div>
              <div style={{ marginBottom: '12px' }}>
                <label style={{ display: 'block', fontSize: '13px', marginBottom: '4px' }}>Descrição</label>
                <textarea value={description} onChange={e => setDescription(e.target.value)} required style={{ width: '100%', padding: '8px', border: '1px solid #d1d5db', borderRadius: '4px', height: '60px' }} />
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', marginBottom: '20px' }}>
                <div>
                  <label style={{ display: 'block', fontSize: '13px', marginBottom: '4px' }}>Nível</label>
                  <input type="number" value={level} onChange={e => setLevel(Number(e.target.value))} style={{ width: '100%', padding: '8px', border: '1px solid #d1d5db', borderRadius: '4px' }} />
                </div>
                <div>
                  <label style={{ display: 'block', fontSize: '13px', marginBottom: '4px' }}>Tema</label>
                  <input type="text" value={theme} onChange={e => setTheme(e.target.value)} style={{ width: '100%', padding: '8px', border: '1px solid #d1d5db', borderRadius: '4px' }} />
                </div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <button type="button" onClick={() => setShowModal(false)} style={{ background: 'none', border: 'none', marginRight: '12px', cursor: 'pointer' }}>Cancelar</button>
                <button type="submit" style={{ padding: '8px 16px', backgroundColor: '#4f46e5', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Salvar Lição</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
