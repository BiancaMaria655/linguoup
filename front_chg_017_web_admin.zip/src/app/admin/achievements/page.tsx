'use client';

import React, { useState } from 'react';
import { useAdminAchievements } from '../../../hooks/useAdminQueries';

export default function AdminAchievementsPage() {
  const { achievements, createAchievement } = useAdminAchievements();
  const [showModal, setShowModal] = useState(false);
  
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [criteria, setCriteria] = useState('');
  const [xpReward, setXpReward] = useState(100);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createAchievement({ name, description, criteria, xpReward });
    setShowModal(false);
    setName(''); setDescription(''); setCriteria('');
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'between', alignItems: 'center', marginBottom: '24px' }}>
        <h2 style={{ fontSize: '24px', fontWeight: 'bold', color: '#111827' }}>Gestão de Conquistas (/admin/achievements)</h2>
        <button onClick={() => setShowModal(true)} style={{ padding: '10px 16px', backgroundColor: '#4f46e5', color: 'white', border: 'none', borderRadius: '6px', cursor: 'pointer', fontWeight: 'bold' }}>
          + Nova Conquista
        </button>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
        {achievements.map(ach => (
          <div key={ach.id} style={{ backgroundColor: 'white', padding: '20px', borderRadius: '8px', border: '1px solid #e5e7eb', boxShadow: '0 1px 2px rgba(0,0,0,0.05)' }}>
            <div style={{ display: 'flex', justifyContent: 'between', alignItems: 'start' }}>
              <div>
                <h4 style={{ margin: '0 0 4px 0', fontSize: '16px', fontWeight: 'bold', color: '#111827' }}>{ach.name}</h4>
                <p style={{ margin: '0 0 12px 0', fontSize: '14px', color: '#4b5563' }}>{ach.description}</p>
                <code style={{ display: 'inline-block', backgroundColor: '#f3f4f6', padding: '4px 8px', borderRadius: '4px', fontSize: '12px', color: '#1f2937' }}>Critério: {ach.criteria}</code>
              </div>
              <span style={{ backgroundColor: '#e0e7ff', color: '#4338ca', padding: '4px 10px', borderRadius: '12px', fontSize: '12px', fontWeight: 'bold' }}>
                +{ach.xpReward} XP
              </span>
            </div>
          </div>
        ))}
      </div>

      {showModal && (
        <div style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.4)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ backgroundColor: 'white', padding: '32px', borderRadius: '8px', width: '440px' }}>
            <h3 style={{ marginBottom: '20px', fontWeight: 'bold' }}>Criar Nova Conquista</h3>
            <form onSubmit={handleSubmit}>
              <div style={{ marginBottom: '12px' }}>
                <label style={{ display: 'block', fontSize: '13px', marginBottom: '4px' }}>Nome da Conquista</label>
                <input type="text" value={name} onChange={e => setName(e.target.value)} required style={{ width: '100%', padding: '8px', border: '1px solid #d1d5db', borderRadius: '4px' }} />
              </div>
              <div style={{ marginBottom: '12px' }}>
                <label style={{ display: 'block', fontSize: '13px', marginBottom: '4px' }}>Descrição</label>
                <input type="text" value={description} onChange={e => setDescription(e.target.value)} required style={{ width: '100%', padding: '8px', border: '1px solid #d1d5db', borderRadius: '4px' }} />
              </div>
              <div style={{ marginBottom: '12px' }}>
                <label style={{ display: 'block', fontSize: '13px', marginBottom: '4px' }}>Critério Técnico (Engine)</label>
                <input type="text" value={criteria} onChange={e => setCriteria(e.target.value)} placeholder="ex: LESSONS_COUNT >= 5" required style={{ width: '100%', padding: '8px', border: '1px solid #d1d5db', borderRadius: '4px' }} />
              </div>
              <div style={{ marginBottom: '20px' }}>
                <label style={{ display: 'block', fontSize: '13px', marginBottom: '4px' }}>Recompensa de XP</label>
                <input type="number" value={xpReward} onChange={e => setXpReward(Number(e.target.value))} style={{ width: '100%', padding: '8px', border: '1px solid #d1d5db', borderRadius: '4px' }} />
              </div>
              <div style={{ textAlign: 'right' }}>
                <button type="button" onClick={() => setShowModal(false)} style={{ background: 'none', border: 'none', marginRight: '12px', cursor: 'pointer' }}>Cancelar</button>
                <button type="submit" style={{ padding: '8px 16px', backgroundColor: '#4f46e5', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Salvar Conquista</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
