import { useState, useEffect } from 'react';
import { Lesson, Achievement, AdminMetrics } from '../types/admin';

// Mock de dados iniciais
const initialLessons: Lesson[] = [
  { id: '1', title: 'Introdução ao BI no Agronegócio', description: 'Conceitos fundamentais de inteligência de mercado.', level: 1, theme: 'Agro', duration: 15, contentJson: '{}', isActive: true },
  { id: '2', title: 'Modelagem de Dados com SQL', description: 'Queries avançadas aplicadas a cenários reais.', level: 2, theme: 'Dados', duration: 20, contentJson: '{}', isActive: true }
];

const initialAchievements: Achievement[] = [
  { id: '1', name: 'Primeiros Passos', description: 'Concluiu a primeira lição do portal.', criteria: 'COMPLETED_LESSONS >= 1', xpReward: 100 },
  { id: '2', name: 'Mestre dos Dados', description: 'Alcançou o nível 10 na plataforma.', criteria: 'LEVEL >= 10', xpReward: 500 }
];

export function useAdminLessons() {
  const [lessons, setLessons] = useState<Lesson[]>(initialLessons);

  const createLesson = async (lesson: O someOmitData) => {
    const newLesson: Lesson = { ...lesson, id: Math.random().toString(), isActive: true } as Lesson;
    setLessons(prev => [...prev, newLesson]);
  };

  const updateLesson = async (id: string, updated: Partial<Lesson>) => {
    setLessons(prev => prev.map(l => l.id === id ? { ...l, ...updated } : l));
  };

  const softDeleteLesson = async (id: string) => {
    setLessons(prev => prev.map(l => l.id === id ? { ...l, isActive: false } : l));
  };

  return { lessons: lessons.filter(l => l.isActive), allLessonsRaw: lessons, createLesson, updateLesson, softDeleteLesson };
}

export function useAdminAchievements() {
  const [achievements, setAchievements] = useState<Achievement[]>(initialAchievements);

  const createAchievement = async (ach: Omit<Achievement, 'id'>) => {
    const newAch: Achievement = { ...ach, id: Math.random().toString() };
    setAchievements(prev => [...prev, newAch]);
  };

  return { achievements, createAchievement };
}
