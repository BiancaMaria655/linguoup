export interface User {
  id: string;
  name: string;
  email: string;
  role: 'ADMIN' | 'SUPER_ADMIN' | 'USER';
}

export interface Lesson {
  id: string;
  title: string;
  description: string;
  level: number;
  theme: string;
  duration: number; // em minutos
  contentJson: string;
  isActive: boolean; // Para Soft Delete
}

export interface Achievement {
  id: string;
  name: string;
  description: string;
  criteria: string;
  xpReward: number;
}

export interface AdminMetrics {
  totalUsers: number;
  totalLessons: number;
  lessonsCompletedToday: number;
}
