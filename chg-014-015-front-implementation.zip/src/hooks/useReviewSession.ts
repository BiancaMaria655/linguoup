import { useState } from 'react';

export interface ReviewItem {
  id: string;
  term: string;
  context: string;
  dueStatus: 'Vencido' | 'Hoje' | 'Agendado';
}

export function useReviewSession() {
  const [reviews, setReviews] = useState<ReviewItem[]>([
    { id: "rev-1", term: "Sales Coverage", context: "Fórmula de cobertura de praça e distribuidores agro.", dueStatus: "Vencido" },
    { id: "rev-2", term: "Sell-Out Tracking", context: "Métricas de escoamento do estoque de insumos no canal.", dueStatus: "Hoje" },
    { id: "rev-3", term: "Commodity Hedging", context: "Proteção cambial e de preço futuro na Bolsa de Chicago.", dueStatus: "Agendado" }
  ]);

  const snoozeItem = (id: string) => {
    setReviews(p => p.filter(item => item.id !== id));
  };

  return {
    reviews,
    snoozeItem
  };
}
