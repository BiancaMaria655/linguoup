import { renderHook, act } from '@testing-library/react';
import { useLessonExecution } from '../useLessonExecution';

describe('useLessonExecution Hook Logic', () => {
  it('deve inicializar o estado da lição corretamente', () => {
    const { result } = renderHook(() => useLessonExecution('lesson-123'));
    expect(result.current.currentIndex).toBe(0);
    expect(result.current.hasSubmitted).toBe(false);
    expect(result.current.score).toBe(0);
  });

  it('deve validar resposta correta e computar pontuação', () => {
    const { result } = renderHook(() => useLessonExecution('lesson-123'));
    
    act(() => {
      result.current.submitAnswer('Sales Coverage (Cobertura de Vendas)');
    });

    expect(result.current.hasSubmitted).toBe(true);
    expect(result.current.isCorrect).toBe(true);
    expect(result.current.score).toBe(1);
  });
});
