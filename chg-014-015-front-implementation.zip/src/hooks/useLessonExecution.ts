import { useState, useEffect } from 'react';

export interface Exercise {
  id: string;
  type: 'multiple_choice' | 'fill_in_the_blanks' | 'translation';
  question: string;
  options?: string[];
  correctAnswer: string;
  explanation: string;
  hint: string;
}

export function useLessonExecution(lessonId: string) {
  const [exercises] = useState<Exercise[]>([
    {
      id: "ex-1",
      type: "multiple_choice",
      question: "Qual indicador mede a relação entre as vendas realizadas e o potencial total de mercado regional?",
      options: ["Market Share", "Sales Coverage (Cobertura de Vendas)", "Churn Rate", "LTV"],
      correctAnswer: "Sales Coverage (Cobertura de Vendas)",
      explanation: "A Cobertura de Vendas avalia o quão bem a equipe atinge a base potencial de clientes mapeada no setor agrícola.",
      hint: "Foca no alcance geográfico e na carteira de produtores."
    },
    {
      id: "ex-2",
      type: "fill_in_the_blanks",
      question: "O cálculo de ____ no Power BI permite cruzar dados de safras passadas com a projeção de sell-out atual.",
      correctAnswer: "DAX",
      explanation: "Expressões DAX são fundamentais para criar métricas de séries temporais aplicadas a safras e ciclos do agronegócio.",
      hint: "Linguagem de fórmulas padrão do Power BI."
    },
    {
      id: "ex-3",
      type: "translation",
      question: "Traduza para termos de negócios: 'Market Intelligence in Agribusiness'",
      correctAnswer: "Inteligência de Mercado no Agronegócio",
      explanation: "Tradução direta e corporativa utilizada para a área analítica do setor produtivo.",
      hint: "Inteligência de..."
    }
  ]);

  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState('');
  const [hasSubmitted, setHasSubmitted] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [score, setScore] = useState(0);
  const [timeSpent, setTimeSpent] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  useEffect(() => {
    if (isPaused || hasSubmitted) return;
    const timer = setInterval(() => setTimeSpent(p => p + 1), 1000);
    return () => clearInterval(timer);
  }, [isPaused, hasSubmitted]);

  const currentExercise = exercises[currentIndex];

  const submitAnswer = (answer: string) => {
    if (hasSubmitted) return;
    setSelectedAnswer(answer);
    const correct = answer.trim().toLowerCase() === currentExercise.correctAnswer.trim().toLowerCase();
    setIsCorrect(correct);
    if (correct) setScore(s => s + 1);
    setHasSubmitted(true);
  };

  const nextQuestion = () => {
    setSelectedAnswer('');
    setHasSubmitted(false);
    setShowHint(false);
    if (currentIndex < exercises.length - 1) {
      setCurrentIndex(currentIndex + 1);
      return false; // Não terminou
    }
    return true; // Terminou a lição
  };

  return {
    exercises,
    currentIndex,
    currentExercise,
    selectedAnswer,
    hasSubmitted,
    isCorrect,
    showHint,
    setShowHint,
    score,
    timeSpent,
    isPaused,
    setIsPaused,
    submitAnswer,
    nextQuestion
  };
}
