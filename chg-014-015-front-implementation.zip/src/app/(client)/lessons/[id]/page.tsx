'use client';

import React, { useState } from 'react';
import { useLessonExecution } from '@/hooks/useLessonExecution';
import { useRouter } from 'next/navigation';

export default function LessonExecutionPage({ params }: { params: { id: string } }) {
  const router = useRouter();
  const {
    exercises,
    currentIndex,
    currentExercise,
    selectedAnswer,
    hasSubmitted,
    isCorrect,
    showHint,
    setShowHint,
    timeSpent,
    isPaused,
    setIsPaused,
    submitAnswer,
    nextQuestion
  } = useLessonExecution(params.id);

  const [textInput, setTextInput] = useState('');

  const progressPercent = Math.round(((currentIndex) / exercises.length) * 100);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const handleContinue = () => {
    const isFinished = nextQuestion();
    setTextInput('');
    if (isFinished) {
      router.push(`/lessons/${params.id}/result?score=${timeSpent}`);
    }
  };

  return (
    <div className="max-w-2xl mx-auto bg-white border border-slate-200 rounded-2xl shadow-sm min-h-[550px] flex flex-col justify-between overflow-hidden relative">
      {/* Top Header & Progresso */}
      <div className="p-4 border-b border-slate-100 flex items-center justify-between gap-4">
        <button onClick={() => setIsPaused(!isPaused)} className="text-slate-400 hover:text-slate-600 font-medium text-sm">
          {isPaused ? '▶️ Retomar' : '⏸️ Pausar'}
        </button>
        <div className="flex-1 bg-slate-100 h-2.5 rounded-full overflow-hidden">
          <div className="bg-emerald-500 h-full transition-all duration-300" style={{ width: `${progressPercent}%` }}></div>
        </div>
        <span className="text-xs font-mono font-bold bg-slate-50 border border-slate-200 text-slate-500 px-2 py-0.5 rounded">
          ⏱️ {formatTime(timeSpent)}
        </span>
      </div>

      {isPaused ? (
        <div className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-slate-50/50">
          <h3 className="text-lg font-bold text-slate-800">Lição em Pausa</h3>
          <p className="text-slate-500 text-sm max-w-xs mt-1">Sua posição local foi guardada temporariamente. Pronto para continuar?</p>
          <button onClick={() => setIsPaused(false)} className="mt-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-5 py-2.5 rounded-lg shadow-sm">
            Retomar Exercício
          </button>
        </div>
      ) : (
        /* Área Central do Exercício */
        <div className="flex-1 p-6 md:p-8">
          <span className="text-[10px] uppercase font-black tracking-widest text-emerald-600">Questão {currentIndex + 1} de {exercises.length}</span>
          <h2 className="text-lg font-bold text-slate-900 mt-2 leading-snug">{currentExercise.question}</h2>

          {/* Dica */}
          <div className="mt-3">
            {!showHint ? (
              <button onClick={() => setShowHint(true)} className="text-xs font-semibold text-slate-400 hover:text-emerald-600 transition-colors">
                💡 Ver dica complementar
              </button>
            ) : (
              <div className="bg-amber-50 border border-amber-200 text-amber-800 rounded-lg p-3 text-xs font-medium">
                {currentExercise.hint}
              </div>
            )}
          </div>

          {/* Renderização Dinâmica conforme Tipo de Exercício */}
          <div className="mt-8 space-y-2.5">
            {currentExercise.type === 'multiple_choice' && currentExercise.options?.map((option) => (
              <button
                key={option}
                disabled={hasSubmitted}
                onClick={() => submitAnswer(option)}
                className={`w-full text-left p-4 rounded-xl border text-sm font-semibold transition-all ${
                  hasSubmitted && option === currentExercise.correctAnswer ? 'bg-emerald-50 border-emerald-500 text-emerald-900' :
                  hasSubmitted && option === selectedAnswer && !isCorrect ? 'bg-rose-50 border-rose-400 text-rose-900' :
                  selectedAnswer === option ? 'border-emerald-600 bg-emerald-50/30' : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-700'
                }`}
              >
                {option}
              </button>
            ))}

            {(currentExercise.type === 'fill_in_the_blanks' || currentExercise.type === 'translation') && (
              <div className="space-y-4">
                <input
                  type="text"
                  disabled={hasSubmitted}
                  value={textInput}
                  onChange={(e) => setTextInput(e.target.value)}
                  placeholder="Digite sua resposta aqui..."
                  className="w-full border border-slate-200 rounded-xl p-4 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                />
                {!hasSubmitted && (
                  <button
                    onClick={() => submitAnswer(textInput)}
                    disabled={!textInput.trim()}
                    className="bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white font-bold text-xs px-5 py-3 rounded-xl transition-all"
                  >
                    Verificar Resposta
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Footer de Feedback Imediato */}
      {hasSubmitted && (
        <div className={`p-6 border-t animate-slideUp ${isCorrect ? 'bg-emerald-50 border-emerald-200' : 'bg-rose-50 border-rose-200'}`}>
          <div className="flex items-start gap-3">
            <span className="text-xl">{isCorrect ? '🎉' : '💡'}</span>
            <div>
              <h4 className={`text-sm font-bold ${isCorrect ? 'text-emerald-900' : 'text-rose-900'}`}>
                {isCorrect ? 'Resposta Correta!' : 'Quase lá! Resposta incorreta'}
              </h4>
              <p className={`text-xs mt-1 font-medium ${isCorrect ? 'text-emerald-700' : 'text-rose-700'}`}>
                {currentExercise.explanation}
              </p>
              {!isCorrect && (
                <p className="text-[11px] font-mono text-rose-600 mt-1">Esperado: {currentExercise.correctAnswer}</p>
              )}
            </div>
          </div>
          <div className="mt-5 flex justify-end">
            <button onClick={handleContinue} className={`font-bold text-xs px-6 py-2.5 rounded-lg shadow-sm text-white ${isCorrect ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-rose-600 hover:bg-rose-700'}`}>
              Continuar →
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
