'use client';

import React from 'react';
import Link from 'next/link';

export default function LessonResultPage() {
  return (
    <div className="max-w-md mx-auto bg-white border border-slate-200 rounded-2xl shadow-sm p-6 text-center space-y-6">
      <div>
        <span className="text-5xl block animate-bounce">🏆</span>
        <h1 className="text-xl font-black text-slate-900 mt-3">Lição Concluída com Sucesso!</h1>
        <p className="text-xs text-slate-500 mt-1">Seu progresso de aprendizado de inteligência agrícola foi computado.</p>
      </div>

      {/* Painel de Recompensa */}
      <div className="bg-slate-50 border border-slate-100 rounded-xl p-4 grid grid-cols-2 gap-3">
        <div className="text-center p-2 border-r border-slate-200">
          <span className="text-xs text-slate-400 font-bold uppercase tracking-wider block">XP Adquirido</span>
          <span className="text-2xl font-black text-purple-600 mt-1 inline-block animate-pulse">+40 XP</span>
        </div>
        <div className="text-center p-2">
          <span className="text-xs text-slate-400 font-bold uppercase tracking-wider block">Ofensiva Atual</span>
          <span className="text-2xl font-black text-orange-600 mt-1 inline-block">5 Dias 🔥</span>
        </div>
      </div>

      {/* Conquista Desbloqueada (Toast/Modal simulado) */}
      <div className="bg-emerald-50 border border-emerald-100 rounded-xl p-3 flex items-center gap-3 text-left">
        <span className="text-2xl">🌱</span>
        <div>
          <h4 className="text-xs font-bold text-emerald-900">Nova conquista desbloqueada!</h4>
          <p className="text-[11px] text-emerald-700 font-medium">Desbravador do Agro: Concluiu sua primeira trilha básica.</p>
        </div>
      </div>

      {/* Botões de Ação */}
      <div className="space-y-2 pt-4">
        <Link href="/dashboard" className="w-full flex items-center justify-center bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs py-3 rounded-xl shadow-sm transition-all">
          Voltar para Home Dashboard
        </Link>
        <Link href="/reviews" className="w-full flex items-center justify-center bg-slate-50 hover:bg-slate-100 text-slate-700 font-semibold text-xs py-2.5 rounded-xl border border-slate-200 transition-all">
          Revisar Conteúdo Acumulado
        </Link>
      </div>
    </div>
  );
}
