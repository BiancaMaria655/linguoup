'use client';

import React, { useState } from 'react';
import { useReviewSession } from '@/hooks/useReviewSession';

export default function ReviewsPage() {
  const { reviews, snoozeItem } = useReviewSession();
  const [showGoalModal, setShowGoalModal] = useState(false);
  const [dailyGoalMinutes, setDailyGoalMinutes] = useState(15);

  const pendingCount = reviews.filter(r => r.dueStatus === 'Vencido' || r.dueStatus === 'Hoje').length;

  return (
    <div className="space-y-6">
      {/* INT-15 Streak e Metas */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-4">
          <span className="text-4xl animate-pulse">🔥</span>
          <div>
            <h2 className="text-base font-bold text-slate-900">Sua Ofensiva: 5 Dias Seguidos</h2>
            <p className="text-slate-500 text-xs">Melhor marca histórica: 14 dias ativos</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-500">Meta: {dailyGoalMinutes} min/dia</span>
          <button onClick={() => setShowGoalModal(true)} className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs px-3 py-1.5 rounded-lg border border-slate-200 transition-colors">
            ⚙️ Alterar Meta
          </button>
        </div>
      </div>

      {/* Calendário de Atividades Simplificado */}
      <div className="bg-white border border-slate-200 rounded-xl p-4">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">Consistência nos últimos 7 dias</h3>
        <div className="grid grid-cols-7 gap-2 text-center">
          {['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'].map((d, i) => (
            <div key={d} className="flex flex-col items-center">
              <span className="text-[10px] text-slate-400 font-medium">{d}</span>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold mt-1 ${i < 5 ? 'bg-emerald-500 text-white shadow-sm' : 'bg-slate-100 text-slate-400'}`}>
                {i + 20}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* INT-17 Repetição Espaçada Listagem */}
      <div className="space-y-3">
        <div className="flex justify-between items-center px-1">
          <div className="flex items-center gap-2">
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-500">Fila de Repetição Espaçada</h2>
            {pendingCount > 0 && (
              <span className="bg-rose-100 text-rose-700 text-[10px] font-bold px-2 py-0.5 rounded-full">{pendingCount} urgentes</span>
            )}
          </div>
        </div>

        <div className="space-y-2.5">
          {reviews.length === 0 ? (
            <div className="p-8 text-center bg-slate-50 border border-dashed rounded-xl text-slate-400 text-xs">
              ✨ Tudo limpo por aqui! Nenhuma revisão pendente para hoje.
            </div>
          ) : (
            reviews.map((item) => (
              <div key={item.id} className="bg-white border border-slate-200 rounded-xl p-4 flex items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-bold text-slate-900">{item.term}</h3>
                    <span className={`text-[9px] font-extrabold uppercase px-1.5 py-0.5 rounded ${
                      item.dueStatus === 'Vencido' ? 'bg-rose-100 text-rose-700' :
                      item.dueStatus === 'Hoje' ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-500'
                    }`}>
                      {item.dueStatus}
                    </span>
                  </div>
                  <p className="text-slate-500 text-xs mt-1">{item.context}</p>
                </div>

                <div className="flex gap-2">
                  <button onClick={() => snoozeItem(item.id)} className="text-slate-400 hover:text-rose-600 font-semibold text-xs px-2.5 py-1.5 rounded-lg border border-transparent hover:border-rose-100 transition-all">
                    Adiar ⏳
                  </button>
                  <a href={`/lessons/review-session`} className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs px-3 py-1.5 rounded-lg shadow-sm transition-colors">
                    Revisar
                  </a>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Modal responsivo de alteração de meta */}
      {showGoalModal && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-xl border border-slate-100 space-y-4">
            <h3 className="text-base font-bold text-slate-900">Configurar Meta Diária</h3>
            <p className="text-slate-500 text-xs">Ajuste o tempo alvo de estudo diário recomendado para o seu perfil.</p>
            
            <div className="space-y-2 pt-2">
              <input 
                type="range" min="5" max="60" step="5" 
                value={dailyGoalMinutes} 
                onChange={(e) => setDailyGoalMinutes(Number(e.target.value))}
                className="w-full accent-emerald-600" 
              />
              <div className="flex justify-between text-xs font-bold text-slate-600">
                <span>5 min</span>
                <span className="text-emerald-600 font-black">{dailyGoalMinutes} minutos/dia</span>
                <span>60 min</span>
              </div>
            </div>

            <div className="pt-2 flex justify-end gap-2">
              <button onClick={() => setShowGoalModal(false)} className="bg-slate-100 text-slate-600 text-xs font-bold px-4 py-2 rounded-lg">
                Salvar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
