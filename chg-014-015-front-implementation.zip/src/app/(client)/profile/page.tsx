'use client';

import React from 'react';

export default function ProfilePage() {
  const achievements = [
    { id: 'ac-1', title: 'Primeiro AgroPasso', desc: 'Completou o onboarding e a primeira lição.', unlocked: true, icon: '🌱' },
    { id: 'ac-2', title: 'Mestre da Cobertura', desc: 'Acertou 5 questões seguidas de DAX para vendas agro.', unlocked: true, icon: '📊' },
    { id: 'ac-3', title: 'Fogo Consistente', desc: 'Atingiu uma ofensiva ativa de 5 dias seguidos.', unlocked: true, icon: '🔥' },
    { id: 'ac-4', title: 'Analista Sênior', desc: 'Dominou todos os termos de commodities agrícolas.', unlocked: false, icon: '🌾' },
    { id: 'ac-5', title: 'Sem Erros', desc: 'Concluiu uma micro-lição sem errar nenhuma alternativa.', unlocked: false, icon: '🎯' }
  ];

  return (
    <div className="space-y-6">
      {/* Gamificação: Barra de Nível Superior */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm space-y-4">
        <div className="flex justify-between items-center">
          <div>
            <span className="text-[10px] uppercase font-black tracking-widest text-emerald-600">Nível do Aluno</span>
            <h2 className="text-xl font-black text-slate-900">Nível 4 — Analista de Inteligência</h2>
          </div>
          <span className="text-xs font-mono font-bold text-slate-400">340 / 500 XP</span>
        </div>
        <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden">
          <div className="bg-gradient-to-r from-emerald-500 to-teal-500 h-full rounded-full" style={{ width: '68%' }}></div>
        </div>
      </div>

      {/* Grid de Conquistas (INT-16) */}
      <div className="space-y-3">
        <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 px-1">Galeria de Conquistas</h3>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {achievements.map((ach) => (
            <div 
              key={ach.id} 
              title={!ach.unlocked ? `Critério de bloqueio: ${ach.desc}` : undefined}
              className={`p-4 rounded-xl border flex items-center gap-4 transition-all ${
                ach.unlocked 
                  ? 'bg-white border-slate-200 hover:border-emerald-200 shadow-sm' 
                  : 'bg-slate-50/70 border-slate-200/60 opacity-60 cursor-help'
              }`}
            >
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-2xl ${
                ach.unlocked ? 'bg-emerald-50' : 'bg-slate-200 grayscale'
              }`}>
                {ach.icon}
              </div>
              <div>
                <h4 className={`text-sm font-bold ${ach.unlocked ? 'text-slate-900' : 'text-slate-500 line-through'}`}>
                  {ach.title}
                </h4>
                <p className="text-slate-400 text-xs mt-0.5">{ach.desc}</p>
                {!ach.unlocked && (
                  <span className="text-[10px] text-amber-600 font-semibold block mt-1">🔒 Bloqueado</span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
