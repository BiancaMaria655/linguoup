'use client';

import React, { useState } from 'react';

export default function ProgressPage() {
  const [period, setPeriod] = useState(7);

  return (
    <div className="space-y-6">
      {/* Cabeçalho e Filtro */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">Seu Progresso Analítico</h1>
          <p className="text-slate-500 text-sm">Métricas de tempo e absorção de conhecimento das sprints.</p>
        </div>
        <select 
          value={period} 
          onChange={(e) => setPeriod(Number(e.target.value))}
          className="border border-slate-200 rounded-lg p-2 text-xs font-bold bg-white text-slate-700"
        >
          <option value={7}>Últimos 7 dias</option>
          <option value={30}>Últimos 30 dias</option>
          <option value={90}>Últimos 90 dias</option>
        </select>
      </div>

      {/* Grid de Stats Rápidos */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Lições Concluídas</span>
          <p className="text-2xl font-black text-slate-800 mt-1">24 lições</p>
          <span className="text-[11px] text-emerald-600 font-semibold mt-1 inline-block">↑ 4 lições essa semana</span>
        </div>
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Tempo Total de Estudo</span>
          <p className="text-2xl font-black text-slate-800 mt-1">4.2 horas</p>
          <span className="text-[11px] text-slate-400 font-medium mt-1 inline-block">Média de 18 min por dia</span>
        </div>
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Vocabulário Agro Absorvido</span>
          <p className="text-2xl font-black text-emerald-600 mt-1">112 Termos</p>
          <span className="text-[11px] text-purple-600 font-semibold mt-1 inline-block">Retenção de 89% no SRS</span>
        </div>
      </div>

      {/* Gráfico de Barras Leve usando SVG Puro Responsivo */}
      <div className="bg-white border border-slate-200 rounded-xl p-5">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-4">Minutos Estudados por Dia</h3>
        <div className="w-full overflow-x-auto">
          <svg className="w-full h-40 min-w-[300px]" viewBox="0 0 400 120" preserveAspectRatio="none">
            {/* Linhas de Grade de Fundo */}
            <line x1="0" y1="20" x2="400" y2="20" stroke="#f1f5f9" strokeWidth="1" />
            <line x1="0" y1="60" x2="400" y2="60" stroke="#f1f5f9" strokeWidth="1" />
            <line x1="0" y1="100" x2="400" y2="100" stroke="#e2e8f0" strokeWidth="1.5" />

            {/* Barras Horizontais Simulando Dias (Seg a Dom) */}
            {/* Cada barra: x, y (100 - altura), width=30, height */}
            <rect x="25" y="40" width="25" height="60" rx="4" fill="#34d399" />
            <rect x="80" y="60" width="25" height="40" rx="4" fill="#10b981" />
            <rect x="135" y="30" width="25" height="70" rx="4" fill="#10b981" />
            <rect x="190" y="75" width="25" height="25" rx="4" fill="#34d399" />
            <rect x="245" y="50" width="25" height="50" rx="4" fill="#059669" />
            <rect x="300" y="90" width="25" height="10" rx="4" fill="#cbd5e1" />
            <rect x="355" y="45" width="25" height="55" rx="4" fill="#10b981" />
          </svg>
          <div className="flex justify-between px-4 text-[10px] text-slate-400 font-bold mt-2">
            <span>Seg</span><span>Ter</span><span>Qua</span><span>Qui</span><span>Sex</span><span>Sáb</span><span>Dom</span>
          </div>
        </div>
      </div>
    </div>
  );
}
