import { test, expect } from '@playwright/test';

test.describe('E2E Complete Journey — CHG-014 & CHG-015', () => {
  test('deve navegar pelo progresso, iniciar revisões e executar uma lição com sucesso', async ({ page }) => {
    // 1. Abrir aba de progresso e verificar gráficos
    await page.goto('/progress');
    await expect(page.locator('text=Seu Progresso Analítico')).toBeVisible();
    await expect(page.locator('text=Vocabulário Agro Absorvido')).toBeVisible();

    // 2. Navegar para a aba de revisões de repetição espaçada
    await page.goto('/reviews');
    await expect(page.locator('text=Sua Ofensiva: 5 Dias Seguidos')).toBeVisible();

    // 3. Abrir a execução de uma microlição ativa
    await page.goto('/lessons/les-401');
    await expect(page.locator('text=Questão 1 de 3')).toBeVisible();

    // Responder a alternativa correta simulada
    await page.locator('text=Sales Coverage (Cobertura de Vendas)').click();
    await expect(page.locator('text=Resposta Correta!')).toBeVisible();

    // Avançar para tela de resultados
    await page.locator('text=Continuar →').click();
  });
});
